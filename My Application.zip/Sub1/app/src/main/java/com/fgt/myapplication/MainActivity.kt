package com.fgt.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.ViewManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.jetbrains.anko.*
import org.jetbrains.anko.custom.ankoView
import org.jetbrains.anko.recyclerview.v7.recyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var adapter: RecyclerViewAdapter
    private var items: MutableList<Item> = mutableListOf()

    private lateinit var listTeam: RecyclerView

    inline fun ViewManager.customFrameLayout(theme: Int = 0, init: FrameLayout.() -> Unit): FrameLayout {
        return ankoView({ FrameLayout(it) }, theme = theme, init = init)


    }




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_main)
        initData()
        mainUI()

        adapter = RecyclerViewAdapter(items){
            startActivity(intentFor<SecondActivity>("name" to it))
        }
        listTeam.adapter=adapter
    }

    private fun initData(){
        val name = resources.getStringArray(R.array.club_name)
        val image = resources.obtainTypedArray(R.array.club_image)
        val desc = resources.getStringArray(R.array.club_desc)
        items.clear()
        for (i in name.indices) {
            items.add(Item(name[i],
                desc[i],
                image.getResourceId(i, 0)

            ))

        }

        //Recycle the typed array
        image.recycle()
    }

    private fun mainUI(){
        linearLayout {
            lparams (width = matchParent, height = wrapContent)
            orientation = LinearLayout.VERTICAL
            topPadding = dip(16)
            leftPadding = dip(16)
            rightPadding = dip(16)



            relativeLayout{
                lparams (width = matchParent, height = wrapContent)

                listTeam = recyclerView {
                    id = R.id.club_list
                    lparams (width = matchParent, height = wrapContent)
                    layoutManager = LinearLayoutManager(ctx)
                }


            }

        }
    }
}
